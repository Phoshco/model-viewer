Converted by Festivity

Link unavailable

======= Info =======
This archive is the unmodified contents of the 
original download.
I'm not the author of this model, and please 
credit the original author 
(A link is even better!).
I only redistributing this model for people 
who are not in the discord server



UPLOADER'S NOTE: The character model is a .fbx, and the
grenade is a .obj, since I don't know how to
convert them to .pmx.

If you know how to do that and want to convert them,
then please, be my guest!

And I don't know who the original artist is, you know,
who originally ripped and rigged her. I got the models
from a Discord server that sadly no longer exists.

All credits go to miHoYo and Guerrilla Games

Hope you have fun using her! 